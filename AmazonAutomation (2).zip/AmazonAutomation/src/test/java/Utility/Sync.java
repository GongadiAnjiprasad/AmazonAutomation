package Utility;

import java.util.concurrent.TimeUnit;

import stepdefinations.BaseClass;

public class Sync extends BaseClass
{
	
	public static void pageLoadWait(int numberOfSeconds)
	{
		driver.manage().timeouts().implicitlyWait(numberOfSeconds, TimeUnit.SECONDS);		
	}

}