package stepdefinations;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Utility.Sync;

public class BaseClass 
{
	
	public static WebDriver driver; // as i declared driver variable as static, this can be accessed without creating object to class
	//  as i declared driver variable as static, driver variable will load when  the class is loaded
	//  as i declared driver variable as public, this can be accessed any where in any package with or without inheritance
	
	public BaseClass()
	{
		
	}
	
	public static void initilize()
	{
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		Sync.pageLoadWait(10);
	}
	
	
	

}
