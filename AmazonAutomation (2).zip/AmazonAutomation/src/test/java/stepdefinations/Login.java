package stepdefinations;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Utility.Sync;
import Utility.TakeScreenShot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login extends BaseClass
{ 
	
	
	@Given("User has launched application")
	public void User_has_launched_application() throws IOException
	{
		BaseClass.initilize();
		driver.get("https://www.amazon.in/");
		TakeScreenShot.captureScreenshot("LaunchApplication");
	}
	
	@When("User enters a valid email address {string} into login field")
	public void User_enters_a_valid_email_address_into_login_field(String emailAddress)
	{
		Sync.pageLoadWait(10);
		Sync.pageLoadWait(10);
		driver.findElement(By.xpath("//div[@class='nav-signin-tt nav-flyout']//descendant::span[text()='Sign in']")).click();
		Sync.pageLoadWait(10);
	    driver.findElement(By.id("ap_email")).sendKeys(emailAddress);
	    driver.findElement(By.id("continue")).click();
	    Sync.pageLoadWait(10);
	}
	
	@And("User enter valid password {string} into password field")
	public void User_enter_valid_password_into_password_field(String password) throws IOException
	{
		driver.findElement(By.id("ap_password")).sendKeys(password);
		TakeScreenShot.captureScreenshot("PasswordScreenshot");
	}
	
	@And("User clicks on login button")
	public void User_clicks_on_login_button()
	{
		driver.findElement(By.id("signInSubmit")).click();
	}
	
	@Then("User should login successfully")
	public void User_should_login_successfully()
	{
	   boolean loginFlag = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']")).getText().contains("prathap");
		Assert.assertEquals(loginFlag, true,"Login Not successful");	
	}
	
	
	
}

//https://www.youtube.com/watch?v=GavBjhAp42o&list=PLFGoYjJG_fqpObjigKg4bunu6_Ki7Ppn-